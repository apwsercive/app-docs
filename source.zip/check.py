"""Integration checks for URLs, translations, release metadata, and expansion."""
from html.parser import HTMLParser
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parent


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.ids, self.lang = [], set(), None
        self.headings, self.viewport, self.main = 0, False, False
        self.alternates = {}

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            assert a["id"] not in self.ids, a["id"]
            self.ids.add(a["id"])
        if tag == "html":
            self.lang = a.get("lang")
            assert a.get("dir") in ("ltr", "rtl")
        if tag == "h1":
            self.headings += 1
        if tag == "main":
            self.main = True
        if tag == "meta" and a.get("name") == "viewport":
            self.viewport = True
            assert "user-scalable=no" not in a["content"]
        assert tag not in ("script", "iframe", "form"), tag
        if tag in ("a", "link"):
            self.links.append(a.get("href", ""))
            if a.get("rel") == "alternate":
                self.alternates[a["hreflang"]] = a["href"]


def check(out, base):
    pages = {}
    for path in out.rglob("*.html"):
        page = Page()
        page.feed(path.read_text(encoding="utf-8"))
        assert page.lang and page.viewport and page.headings == 1 and page.main, path
        pages[path] = page
    for path, page in pages.items():
        for href in page.links:
            url = urlsplit(href)
            if url.scheme:
                assert url.scheme in ("https", "mailto"), href
                continue
            if not url.path:
                target = path
            else:
                assert url.path.startswith(base + "/"), (path, href)
                target = out / unquote(url.path[len(base)+1:])
                if url.path.endswith("/"):
                    target /= "index.html"
                assert target.exists(), (path, href)
            if url.fragment:
                assert target in pages and url.fragment in pages[target].ids, (path, href)
        for lang, href in page.alternates.items():
            target = out / href[len(base)+1:] / "index.html"
            assert pages[target].lang == lang
    assert (out / ".nojekyll").exists()
    return len(pages)


def run():
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp) / "site"
        shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns("dist", "__pycache__", ".git"))
        spec = importlib.util.spec_from_file_location("site_build", work / "build.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for label, base in (("root", ""), ("project", "/app-docs")):
            out = Path(tmp) / label
            module.build(base, out)
            assert check(out, base) == 10
            en = (out / "kongming/en/privacy/index.html").read_text()
            assert f'{base}/kongming/zh-Hans/privacy/' in en
            assert 'id="location"' in en and 'GitHub' in en
        try:
            module.build(output=Path(tmp)/"release-rejected", release=True)
        except ValueError as error:
            assert "Release needs" in str(error)
        else:
            raise AssertionError("Incomplete release was accepted")
        config = json.loads((work/"site.json").read_text())
        config["publisher"] = {"name":"Test operator", "email":"test@example.com"}
        config["locales"]["ar"] = dict(config["locales"]["en"], label="العربية", dir="rtl")
        config["apps"]["example-app"] = {"names":{"ar":"Example"}, "documents":["support"]}
        source = json.loads((work/"content/kongming/en/privacy.json").read_text())
        source["title"] = "Support"
        target = work/"content/example-app/ar/support.json"
        target.parent.mkdir(parents=True)
        target.write_text(json.dumps(source))
        (work/"site.json").write_text(json.dumps(config))
        for path in (work/"content").rglob("*.json"):
            doc = json.loads(path.read_text())
            doc.update(status="published", effective="2026-10-29")
            path.write_text(json.dumps(doc))
        out = Path(tmp)/"expanded"
        module.build("/documents", out, release=True)
        assert check(out, "/documents") == 14
        ar = (out/"example-app/ar/support/index.html").read_text()
        assert 'dir="rtl"' in ar
        assert '/example-app/en/support/' not in ar
        assert 'noindex' not in ar
        print("Passed: root/project URLs, 10 pages, anchors, language switching, release validation, additional app/document and RTL locale (14 pages).")


if __name__ == "__main__":
    run()
